/**
 * CORE Platform - Main Application JavaScript
 * @description Core functionality for authentication, database operations, and user management
 * @version 2.0.0
 * @license ISC
 * 
 * This file handles:
 * 1. User authentication (both admin and employee)
 * 2. Company registration
 * 3. Department point management
 * 4. Leaderboard functionality
 * 5. Email notifications
 */

'use strict';

// --- Constants and Configuration ---
const ROUTES = {
  ADMIN: '/admin.html',
  EMPLOYEE: '/employee.html',
  LOGIN: '/index-login.html',
  EMPLOYEE_LOGIN: '/employee-login.html'
};

/**
 * User-friendly error messages for all possible error scenarios
 * These messages are designed to be clear and actionable for end users
 */
const ERROR_MESSAGES = {
  AUTH_FAILED: 'Unable to log in. Please check your email and password and try again.',
  ADMIN_REQUIRED: 'This account does not have administrator privileges. Please log in with an admin account.',
  EMAIL_FAILED: 'Your account was created successfully, but we could not send the confirmation email. Please save your login information.',
  NETWORK_ERROR: 'Unable to connect to the server. Please check your internet connection and try again.',
  INVALID_INPUT: 'Please fill in all required fields correctly.',
  DATABASE_ERROR: 'Unable to save changes. Please try again in a few moments.',
  INVALID_EMAIL: 'Please enter a valid email address.',
  PASSWORD_WEAK: 'Password must be at least 6 characters long and include a number.',
  COMPANY_EXISTS: 'This company is already registered. Please contact support if you need assistance.',
  DEPARTMENT_EXISTS: 'This department already exists. Please use a different name.',
  POINTS_INVALID: 'Please enter a valid number of points.',
  SESSION_EXPIRED: 'Your session has expired. Please log in again to continue.',
  ACCESS_DENIED: 'You do not have permission to access this page.',
  REGISTRATION_FAILED: 'Unable to complete registration. Please try again or contact support.'
};

// --- Firebase Configuration ---
const firebaseConfig = {
  apiKey: "AIzaSyCGW4_VqassdGCOJaGPkYLGYYvBs4QMcME",
  authDomain: "core-iii-web.firebaseapp.com",
  projectId: "core-iii-web",
  storageBucket: "core-iii-web.appspot.com",
  messagingSenderId: "22933808877",
  appId: "1:22933808877:web:f8494e90f24ca75eaa0ee4",
  measurementId: "G-3R70JDVY01"
};

// Initialize Firebase with modern SDK
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.getAuth(app);
const db = firebase.getFirestore(app);

/**
 * List of restricted department names
 * These names are reserved for system use and cannot be used as department names
 * to prevent confusion with administrative roles
 */
const bannedNames = [
  "hr", "management", "human resources", "managers", "admin", "executives"
];

/**
 * Gets current timestamp in milliseconds
 * Used for tracking creation dates and update times
 * @returns {number} Current timestamp
 */
const now = () => new Date().getTime();

/**
 * Initializes the email notification service
 * Sets up error handling for email delivery failures
 */
document.addEventListener("DOMContentLoaded", () => {
  if (typeof emailjs !== "undefined") {
    try {
      emailjs.init("gn6ldKkOG1-i58EOG");
      console.log("Email service initialized successfully");
    } catch (error) {
      console.error("Email service initialization failed:", error);
      showError("Email notifications may not work properly. Please save any important information manually.");
    }
  } else {
    console.error("Email service not available");
    showError("Email notifications are currently unavailable. Please save any important information manually.");
  }
});

/**
 * Handles user logout process
 * Signs out the user and redirects to landing page
 * Includes error handling for failed logout attempts
 */
function logout() {
  auth.signOut()
    .then(() => {
      window.location.href = "index-landing-page.html";
    })
    .catch(error => {
      console.error("Logout failed:", error);
      showError("Unable to log out properly. Please close your browser and try again.");
    });
}

/**
 * Handles the company registration process
 * Creates admin account, company profile, and sends confirmation email
 * Includes comprehensive error handling and user feedback
 */
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registerForm");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const company = document.getElementById("companyName").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    // Input validation
    if (!company || !email || !password) {
      showError(ERROR_MESSAGES.INVALID_INPUT);
      return;
    }

    if (!isValidEmail(email)) {
      showError(ERROR_MESSAGES.INVALID_EMAIL);
      return;
    }

    try {
      // Create authentication account
      const cred = await auth.createUserWithEmailAndPassword(email, password);
      const uid = cred.user.uid;

      // Create company profile
      await db.collection("companies").doc(uid).set({
        name: company,
        email: email,
        createdAt: now(),
        status: 'active'
      });

      // Set up admin privileges
      await db.collection("admins").doc(uid).set({
        email: email,
        company: company,
        role: 'admin',
        createdAt: now()
      });

      // Send welcome email
      try {
        await emailjs.send("service_nk46jxr", "template_4n630w9", {
          company_name: company,
          to_email: email
        });
        console.log("Welcome email sent successfully");
      } catch (emailError) {
        console.error("Welcome email failed:", emailError);
        showError(ERROR_MESSAGES.EMAIL_FAILED);
      }

      // Redirect to login page
      showError("Registration successful! You can now log in.", "success-message");
      setTimeout(() => {
        window.location.href = "index-login.html";
      }, 2000);

    } catch (err) {
      console.error("Registration error:", err);
      let errorMessage = ERROR_MESSAGES.REGISTRATION_FAILED;
      
      // Provide specific error messages for common registration issues
      if (err.code === 'auth/email-already-in-use') {
        errorMessage = "This email is already registered. Please use a different email or contact support.";
      } else if (err.code === 'auth/weak-password') {
        errorMessage = ERROR_MESSAGES.PASSWORD_WEAK;
      }
      
      showError(errorMessage);
    }
  });
});

// --- Utility Functions ---
/**
 * Displays error or success messages to the user
 * @param {string} message - The message to display
 * @param {string} elementId - ID of the element to show message in (optional)
 * @param {string} type - Type of message ('error' or 'success')
 */
const showError = (message, elementId = 'error-message', type = 'error') => {
  const element = document.querySelector(`#${elementId}`) || 
                 document.querySelector('.form-feedback');
  if (element) {
    element.textContent = message;
    element.setAttribute('role', 'alert');
    element.className = `form-feedback ${type}`;
    element.style.color = type === 'success' ? '#28a745' : 'var(--error-color)';
  } else {
    // Fallback to alert if no suitable element found
    alert(message);
  }
};

/**
 * Validates email format using RFC 5322 standard
 * @param {string} email - The email to validate
 * @returns {boolean} - True if email is valid
 */
const isValidEmail = (email) => {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return emailRegex.test(email);
};

// --- Authentication Functions ---
/**
 * Handles admin login process
 * Validates credentials and checks admin privileges
 * @param {Event} event - Form submission event
 */
const handleAdminLogin = async (event) => {
  event.preventDefault();
  
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  
  // Input validation
  if (!email || !password) {
    showError(ERROR_MESSAGES.INVALID_INPUT);
    return;
  }

  if (!isValidEmail(email)) {
    showError(ERROR_MESSAGES.INVALID_EMAIL);
    return;
  }

  try {
    const userCredential = await auth.signInWithEmailAndPassword(email, password);
    const user = userCredential.user;
    
    // Verify admin privileges
    const userDoc = await db.collection('admins').doc(user.uid).get();
    
    if (!userDoc.exists) {
      await auth.signOut();
      throw new Error(ERROR_MESSAGES.ADMIN_REQUIRED);
    }
    
    // Successful login - redirect to admin dashboard
    showError("Login successful! Redirecting...", "success-message", "success");
    setTimeout(() => {
      window.location.href = ROUTES.ADMIN;
    }, 1000);
  } catch (error) {
    console.error('Admin login error:', error);
    let errorMessage = ERROR_MESSAGES.AUTH_FAILED;
    
    // Provide specific error messages for common login issues
    if (error.code === 'auth/user-not-found') {
      errorMessage = "No account found with this email. Please check your email or register.";
    } else if (error.code === 'auth/wrong-password') {
      errorMessage = "Incorrect password. Please try again or reset your password.";
    } else if (error.code === 'auth/too-many-requests') {
      errorMessage = "Too many failed attempts. Please try again later or reset your password.";
    }
    
    showError(errorMessage);
  }
};

/**
 * Handles employee login process
 * Validates credentials and checks employee status
 * @param {Event} event - Form submission event
 */
const handleEmployeeLogin = async (event) => {
  event.preventDefault();
  
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  
  // Input validation
  if (!email || !password) {
    showError(ERROR_MESSAGES.INVALID_INPUT);
    return;
  }

  if (!isValidEmail(email)) {
    showError(ERROR_MESSAGES.INVALID_EMAIL);
    return;
  }

  try {
    const userCredential = await auth.signInWithEmailAndPassword(email, password);
    const user = userCredential.user;
    
    // Verify employee status
    const employeeDoc = await db.collection('employees').doc(user.uid).get();
    
    if (!employeeDoc.exists) {
      await auth.signOut();
      throw new Error('This account is not registered as an employee. Please use the correct login page.');
    }
    
    // Successful login - redirect to employee dashboard
    showError("Login successful! Redirecting...", "success-message", "success");
    setTimeout(() => {
      window.location.href = ROUTES.EMPLOYEE;
    }, 1000);
  } catch (error) {
    console.error('Employee login error:', error);
    let errorMessage = ERROR_MESSAGES.AUTH_FAILED;
    
    // Provide specific error messages for common login issues
    if (error.code === 'auth/user-not-found') {
      errorMessage = "No account found with this email. Please contact your administrator.";
    } else if (error.code === 'auth/wrong-password') {
      errorMessage = "Incorrect password. Please try again or contact your administrator to reset.";
    } else if (error.code === 'auth/too-many-requests') {
      errorMessage = "Too many failed attempts. Please try again later.";
    }
    
    showError(errorMessage);
  }
};

// --- Event Listeners ---
document.addEventListener('DOMContentLoaded', () => {
  // Setup login form handlers
  const adminLoginForm = document.getElementById('adminLoginForm');
  const employeeLoginForm = document.getElementById('employeeLoginForm');
  
  if (adminLoginForm) {
    adminLoginForm.addEventListener('submit', handleAdminLogin);
  }
  
  if (employeeLoginForm) {
    employeeLoginForm.addEventListener('submit', handleEmployeeLogin);
  }
  
  // Setup auth state observer
  auth.onAuthStateChanged((user) => {
    if (user) {
      console.log('User is signed in:', user.email);
    } else {
      console.log('No user is signed in');
    }
  });
});

// --- Error Handling ---
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled promise rejection:', event.reason);
  showError(ERROR_MESSAGES.NETWORK_ERROR);
});

// Prevent form resubmission on page refresh
if (window.history.replaceState) {
  window.history.replaceState(null, null, window.location.href);
}

/**
 * Adds points to a department's score
 * Validates input, updates department document, and refreshes leaderboard
 * Includes error handling for invalid inputs and database operations
 */
async function addPoints() {
  const name = document.getElementById("scoreDeptName").value.trim();
  const points = parseInt(document.getElementById("scorePoints").value.trim());

  // Input validation
  if (!name) {
    showError("Please enter a department name.");
    return;
  }

  if (isNaN(points) || points === 0) {
    showError("Please enter a valid number of points (non-zero).");
    return;
  }

  if (bannedNames.includes(name.toLowerCase())) {
    showError("This department name is reserved and cannot be used.");
    return;
  }

  try {
    const ref = db.collection("departments").doc(name);
    const snap = await ref.get();

    if (snap.exists) {
      // Update existing department
      const current = snap.data().points || 0;
      await ref.update({
        points: current + points,
        lastUpdated: now(),
        history: firebase.firestore.FieldValue.arrayUnion({
          date: now(),
          points,
          type: 'add'
        })
      });
    } else {
      // Create new department
      await ref.set({
        points: points,
        createdAt: now(),
        lastUpdated: now(),
        history: [{
          date: now(),
          points,
          type: 'initial'
        }],
        streak: 0,
        wins: 0
      });
    }

    showError(`Successfully ${snap.exists ? 'updated' : 'created'} department ${name} with ${points} points.`, 'success-message', 'success');
    loadLeaderboard();
  } catch (error) {
    console.error("Error managing points:", error);
    showError("Unable to update points. Please try again.");
  }
}

/**
 * Edits the total points for a department
 * Validates input, updates department document, and maintains history
 * Includes error handling for invalid inputs and database operations
 */
async function editPoints() {
  const name = document.getElementById("editDeptName").value.trim();
  const total = parseInt(document.getElementById("editDeptPoints").value.trim());
  
  // Input validation
  if (!name) {
    showError("Please enter a department name.");
    return;
  }

  if (isNaN(total)) {
    showError("Please enter a valid point value.");
    return;
  }

  try {
    const ref = db.collection("departments").doc(name);
    const snap = await ref.get();

    if (snap.exists) {
      const oldTotal = snap.data().points || 0;
      await ref.update({
        points: total,
        lastUpdated: now(),
        history: firebase.firestore.FieldValue.arrayUnion({ 
          date: now(), 
          points: total,
          oldTotal: oldTotal,
          type: 'edit'
        })
      });
      
      showError(`Successfully updated ${name}'s total points to ${total}.`, 'success-message', 'success');
      loadLeaderboard();
    } else {
      showError("Department not found. Please check the name and try again.");
    }
  } catch (error) {
    console.error("Error editing points:", error);
    showError("Unable to update department points. Please try again.");
  }
}

/**
 * Loads and displays the department leaderboard
 * Updates department achievements and badges
 * Includes error handling for database operations
 */
async function loadLeaderboard() {
  const list = document.getElementById("leaderboardList");
  if (!list) return;
  
  try {
    list.innerHTML = "<li>Loading leaderboard...</li>";

    const snap = await db.collection("departments").orderBy("points", "desc").get();
    const departments = [];
    
    snap.forEach(doc => {
      const data = doc.data();
      data.name = doc.id;
      departments.push(data);
    });

    // Update achievements for top department
    if (departments.length > 0) {
      const topDept = departments[0];
      const ref = db.collection("departments").doc(topDept.name);
      const deptData = await ref.get();
      
      if (deptData.exists) {
        let streak = deptData.data().streak || 0;
        streak++;
        
        await ref.update({
          streak,
          lastUpdated: now(),
          ...(streak === 1 && { goldAwarded: now() }),
          ...(streak >= 3 && { trophyAwarded: now() })
        });
      }
    }

    // Display departments and achievements
    if (departments.length === 0) {
      list.innerHTML = "<li>No departments found. Add points to see the leaderboard.</li>";
      return;
    }

    list.innerHTML = "";
    departments.forEach((dept, index) => {
      const li = document.createElement("li");
      const position = index + 1;
      
      // Add position indicator (🥇, 🥈, 🥉 for top 3)
      const medal = position === 1 ? "🥇" : position === 2 ? "🥈" : position === 3 ? "🥉" : "";
      
      li.textContent = `${medal} ${dept.name}: ${dept.points} points`;
      
      // Add achievement badges
      const span = document.createElement("span");
      const badges = [];

      if (dept.trophyAwarded) {
        badges.push(`<span title="🏆 3-Week Streak Champion (Achieved: ${new Date(dept.trophyAwarded).toLocaleDateString()})">🏆</span>`);
      }
      if (dept.goldAwarded) {
        badges.push(`<span title="⭐ First Place Achievement (Achieved: ${new Date(dept.goldAwarded).toLocaleDateString()})">⭐</span>`);
      }

      // Check weekly achievement
      const weekAgo = now() - 7 * 24 * 60 * 60 * 1000;
      const weeklyPoints = (dept.history || [])
        .filter(e => e.date >= weekAgo)
        .reduce((sum, e) => sum + (e.points || 0), 0);
        
      if (weeklyPoints >= 200) {
        badges.push(`<span title="🔥 High Achiever: ${weeklyPoints} points this week">🔥</span>`);
      }

      span.innerHTML = badges.join(" ");
      li.appendChild(span);
      list.appendChild(li);
    });
  } catch (error) {
    console.error("Error loading leaderboard:", error);
    list.innerHTML = "<li>Unable to load the leaderboard. Please refresh the page.</li>";
  }
}

/**
 * Authentication state observer
 * Handles page access control and initial data loading
 * Includes error handling for authentication and permission checks
 */
auth.onAuthStateChanged(async user => {
  const pageId = document.body.id;
  
  if (pageId === "admin-dashboard") {
    if (!user) {
      window.location.href = ROUTES.LOGIN;
      return;
    }

    try {
      const adminDoc = await db.collection("admins").doc(user.uid).get();
      if (!adminDoc.exists) {
        await auth.signOut();
        showError(ERROR_MESSAGES.ADMIN_REQUIRED);
        setTimeout(() => {
          window.location.href = ROUTES.LOGIN;
        }, 2000);
        return;
      }
      
      // Load dashboard data
      loadLeaderboard();
    } catch (error) {
      console.error("Error verifying admin status:", error);
      showError("Unable to verify your admin privileges. Please try logging in again.");
      setTimeout(() => {
        auth.signOut();
        window.location.href = ROUTES.LOGIN;
      }, 2000);
    }
  }
});

/**
 * Handles error report submission
 * Validates input, saves to database, and sends email notification
 * @param {Event} event - Form submission event
 */
async function submitErrorReport(event) {
  event.preventDefault();
  
  const description = document.getElementById('error-message').value.trim();
  const errorType = document.getElementById('error-type').value;
  const steps = document.getElementById('steps').value.trim();
  const browserInfo = document.getElementById('browser-info').value;
  const pageUrl = document.getElementById('page-url').value;
  const timestamp = document.getElementById('timestamp').value;

  // Input validation
  if (!description || !errorType) {
    showError('Please fill in all required fields.');
    return;
  }

  if (description.length < 20) {
    showError('Please provide a more detailed description (minimum 20 characters).');
    return;
  }

  try {
    // Get current user and verify authentication
    const user = auth.currentUser;
    if (!user) {
      showError('Your session has expired. Please log in again.');
      setTimeout(() => {
        window.location.href = ROUTES.LOGIN;
      }, 2000);
      return;
    }

    // Get user's department if available
    let userDepartment = '';
    try {
      const employeeDoc = await db.collection('employees').doc(user.uid).get();
      if (employeeDoc.exists) {
        userDepartment = employeeDoc.data().department || '';
      }
    } catch (error) {
      console.error('Error fetching department:', error);
      // Continue without department info
    }

    // Create error report document
    const errorReport = {
      userId: user.uid,
      userEmail: user.email,
      department: userDepartment,
      description,
      errorType,
      steps,
      systemInfo: {
        browser: browserInfo,
        page: pageUrl,
        timestamp: new Date(timestamp)
      },
      status: 'new',
      createdAt: now(),
      lastUpdated: now()
    };

    // Save to database with retry
    let reportRef;
    try {
      reportRef = await db.collection('errorReports').add(errorReport);
    } catch (dbError) {
      console.error('Database error:', dbError);
      if (dbError.code === 'permission-denied') {
        throw new Error('You do not have permission to submit reports. Please contact your administrator.');
      }
      throw new Error('Unable to save your report. Please try again.');
    }

    // Send email notification with template verification
    try {
      // Verify EmailJS is initialized
      if (typeof emailjs === 'undefined') {
        throw new Error('Email service not initialized');
      }

      const emailTemplate = {
        report_id: reportRef.id,
        user_email: user.email,
        error_type: errorType,
        description: description.substring(0, 500), // Limit description length for email
        department: userDepartment,
        page_url: pageUrl,
        timestamp: new Date(timestamp).toLocaleString()
      };

      await emailjs.send('service_nk46jxr', 'template_error_report', emailTemplate);
      console.log('Error report notification sent successfully');
    } catch (emailError) {
      console.error('Failed to send error report notification:', emailError);
      // Update database to mark email failure
      try {
        await reportRef.update({
          emailStatus: 'failed',
          emailError: emailError.message
        });
      } catch (updateError) {
        console.error('Failed to update email status:', updateError);
      }
    }

    // Show success message
    showError(
      'Your report has been submitted successfully. Reference ID: ' + reportRef.id, 
      'success-message', 
      'success'
    );

    // Reset form after delay
    setTimeout(() => {
      const form = document.getElementById('errorForm');
      if (form) {
        form.reset();
        // Reset hidden fields
        document.getElementById('browser-info').value = navigator.userAgent;
        document.getElementById('page-url').value = window.location.href;
        document.getElementById('timestamp').value = new Date().toISOString();
      }
    }, 2000);

  } catch (error) {
    console.error('Error submitting report:', error);
    
    let errorMessage = error.message || 'Unable to submit your report. ';
    if (error.code === 'permission-denied') {
      errorMessage = 'You do not have permission to submit reports. Please contact your administrator.';
    } else if (error.code === 'unauthenticated') {
      errorMessage = 'Please log in and try again.';
    } else if (!navigator.onLine) {
      errorMessage = 'You appear to be offline. Please check your internet connection and try again.';
    } else {
      errorMessage += ' Please try again or contact support directly.';
    }
    
    showError(errorMessage);
    throw error; // Re-throw to trigger the form's error handling
  }
}
