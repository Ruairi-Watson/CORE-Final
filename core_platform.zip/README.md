# CORE Platform

Employee Management System with error reporting and department tracking.

## Quick Deploy to AWS

1. Install AWS CLI and configure credentials:
```bash
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
aws configure  # Enter your AWS credentials
```

2. Run the deployment script:
```bash
npm run deploy
```

## Manual Setup

1. Clone the repository:
```bash
git clone <your-repo-url>
cd core-platform
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file:
```env
FIREBASE_API_KEY=your_api_key
FIREBASE_AUTH_DOMAIN=your_domain
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_bucket
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id
FIREBASE_MEASUREMENT_ID=your_measurement_id
EMAILJS_PUBLIC_KEY=your_emailjs_key
EMAILJS_SERVICE_ID=your_service_id
EMAILJS_TEMPLATE_ID=your_template_id
```

4. Start the application:
```bash
# Development
npm run dev

# Production
npm start
```

## AWS Cloud9 Setup

1. Access your Cloud9 environment URL (provided after deployment)
2. Clone the repository
3. Run `npm install`
4. Configure environment variables
5. Start the application with PM2:
```bash
pm2 start app.js
pm2 startup
pm2 save
```

## EC2 Setup

The deployment script automatically:
- Creates necessary security groups
- Sets up IAM roles
- Configures Apache
- Installs Node.js and PM2
- Deploys the application

## Environment Variables

Create a `.env` file in your Cloud9 environment with:

```env
# Firebase Configuration
FIREBASE_API_KEY=your_api_key
FIREBASE_AUTH_DOMAIN=your_domain
FIREBASE_PROJECT_ID=your_project_id
FIREBASE_STORAGE_BUCKET=your_bucket
FIREBASE_MESSAGING_SENDER_ID=your_sender_id
FIREBASE_APP_ID=your_app_id
FIREBASE_MEASUREMENT_ID=your_measurement_id

# EmailJS Configuration
EMAILJS_PUBLIC_KEY=your_emailjs_key
EMAILJS_SERVICE_ID=your_service_id
EMAILJS_TEMPLATE_ID=your_template_id
```

## Security Notes

1. Update security group rules as needed
2. Set up HTTPS using AWS Certificate Manager
3. Configure Firebase security rules
4. Set up proper IAM roles and permissions
5. Enable AWS WAF if needed

## Maintenance

- Monitor logs: `pm2 logs`
- Restart application: `pm2 restart app`
- View status: `pm2 status`
- Update dependencies: `npm update`

## Troubleshooting

1. Check Apache logs:
```bash
sudo tail -f /var/log/httpd/error.log
```

2. Check PM2 logs:
```bash
pm2 logs
```

3. Check security group settings:
```bash
aws ec2 describe-security-groups --group-names "core-platform-sg"
```

4. Verify IAM roles:
```bash
aws iam get-role --role-name core-platform-role
```

## Support

For issues:
1. Check the error logs
2. Use the error reporting system
3. Contact system administrator

## License

ISC License 